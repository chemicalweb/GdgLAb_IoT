<?
	$myFile = "fold/testFile.txt";
	$fh = fopen($myFile, 'w') or die("can't open file");

	if( isset($_GET['gcmid']) )
		$stringData =  $_GET['gcmid'];
	
	fwrite($fh, $stringData);
	fclose($fh);
?>
